package com.projectassignment.lecturemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LecturemanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
