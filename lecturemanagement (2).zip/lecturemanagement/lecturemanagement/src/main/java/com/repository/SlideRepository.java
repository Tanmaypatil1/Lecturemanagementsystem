package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.Slide;

public interface SlideRepository extends JpaRepository<Slide, Long>{

}
